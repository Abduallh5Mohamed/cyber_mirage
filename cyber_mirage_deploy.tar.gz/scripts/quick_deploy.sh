#!/bin/bash
#═══════════════════════════════════════════════════════════════════════════════
# 🚀 Cyber Mirage - Quick Deploy Script
# Run this on a fresh Ubuntu 22.04 EC2 instance
#═══════════════════════════════════════════════════════════════════════════════

set -e  # Exit on error

echo "╔══════════════════════════════════════════════════════════════════╗"
echo "║          🛡️  Cyber Mirage - Quick Deploy Script                  ║"
echo "╚══════════════════════════════════════════════════════════════════╝"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

print_step() {
    echo -e "\n${GREEN}▶ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠ $1${NC}"
}

print_error() {
    echo -e "${RED}✖ $1${NC}"
}

# ─────────────────────────────────────────────────────────────────────────────
# Step 1: Update System
# ─────────────────────────────────────────────────────────────────────────────
print_step "Step 1/6: Updating system..."
sudo apt update && sudo apt upgrade -y

# ─────────────────────────────────────────────────────────────────────────────
# Step 2: Install Docker
# ─────────────────────────────────────────────────────────────────────────────
print_step "Step 2/6: Installing Docker..."
if ! command -v docker &> /dev/null; then
    curl -fsSL https://get.docker.com -o get-docker.sh
    sudo sh get-docker.sh
    sudo usermod -aG docker ubuntu
    rm get-docker.sh
else
    echo "Docker already installed"
fi

# ─────────────────────────────────────────────────────────────────────────────
# Step 3: Install Docker Compose
# ─────────────────────────────────────────────────────────────────────────────
print_step "Step 3/6: Installing Docker Compose..."
if ! command -v docker-compose &> /dev/null; then
    sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
    sudo chmod +x /usr/local/bin/docker-compose
else
    echo "Docker Compose already installed"
fi

# ─────────────────────────────────────────────────────────────────────────────
# Step 4: Clone Repository
# ─────────────────────────────────────────────────────────────────────────────
print_step "Step 4/6: Cloning repository..."
cd /home/ubuntu
if [ ! -d "cyber_mirage" ]; then
    git clone https://github.com/Abduallh5Mohamed/cyber_mirage.git
else
    echo "Repository already exists, pulling latest..."
    cd cyber_mirage && git pull && cd ..
fi

# ─────────────────────────────────────────────────────────────────────────────
# Step 5: Setup Environment
# ─────────────────────────────────────────────────────────────────────────────
print_step "Step 5/6: Setting up environment..."
cd /home/ubuntu/cyber_mirage

if [ ! -f ".env.production" ]; then
    print_warning "Creating .env.production from example..."
    cp .env.example .env.production
    
    # Generate random passwords
    POSTGRES_PASS=$(openssl rand -base64 24 | tr -dc 'a-zA-Z0-9!@#$%' | head -c 24)
    REDIS_PASS=$(openssl rand -base64 24 | tr -dc 'a-zA-Z0-9!@#$%' | head -c 24)
    GRAFANA_PASS=$(openssl rand -base64 16 | tr -dc 'a-zA-Z0-9' | head -c 16)
    GRAFANA_SECRET=$(openssl rand -base64 32)
    
    # Update passwords in .env.production
    sed -i "s/POSTGRES_PASSWORD=.*/POSTGRES_PASSWORD=$POSTGRES_PASS/" .env.production
    sed -i "s/REDIS_PASSWORD=.*/REDIS_PASSWORD=$REDIS_PASS/" .env.production
    sed -i "s/GRAFANA_PASSWORD=.*/GRAFANA_PASSWORD=$GRAFANA_PASS/" .env.production
    sed -i "s/GRAFANA_SECRET=.*/GRAFANA_SECRET=$GRAFANA_SECRET/" .env.production
    
    echo ""
    echo "╔══════════════════════════════════════════════════════════════════╗"
    echo "║  🔐 GENERATED PASSWORDS - SAVE THESE!                            ║"
    echo "╠══════════════════════════════════════════════════════════════════╣"
    echo "║  PostgreSQL: $POSTGRES_PASS"
    echo "║  Redis:      $REDIS_PASS"
    echo "║  Grafana:    $GRAFANA_PASS"
    echo "╚══════════════════════════════════════════════════════════════════╝"
    echo ""
else
    echo ".env.production already exists"
fi

# ─────────────────────────────────────────────────────────────────────────────
# Step 6: Build & Start Services
# ─────────────────────────────────────────────────────────────────────────────
print_step "Step 6/6: Building and starting services..."

# Need to use newgrp to access docker without re-login
sg docker -c "docker-compose -f docker-compose.production.yml up -d --build"

# ─────────────────────────────────────────────────────────────────────────────
# Complete
# ─────────────────────────────────────────────────────────────────────────────
echo ""
echo "╔══════════════════════════════════════════════════════════════════╗"
echo "║  ✅ DEPLOYMENT COMPLETE!                                         ║"
echo "╠══════════════════════════════════════════════════════════════════╣"
echo "║                                                                  ║"
echo "║  📊 Dashboard:   http://$(curl -s ifconfig.me):8501              ║"
echo "║  📈 Grafana:     http://$(curl -s ifconfig.me):3000              ║"
echo "║  📉 Prometheus:  http://$(curl -s ifconfig.me):9090              ║"
echo "║                                                                  ║"
echo "║  🍯 Honeypots are now active and listening!                      ║"
echo "║                                                                  ║"
echo "╚══════════════════════════════════════════════════════════════════╝"
echo ""
print_step "Checking container status..."
sg docker -c "docker ps --format 'table {{.Names}}\t{{.Status}}'"
