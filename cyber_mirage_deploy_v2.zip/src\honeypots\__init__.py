"""src.honeypots package - minimal placeholder for honeypot code.

This file exists so the Docker build that copies ./src/honeypots will have
an importable package. The real project can replace these files with the
full implementation later.
"""

__all__ = ["honeypot_manager"]
